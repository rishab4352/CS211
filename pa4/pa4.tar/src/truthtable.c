#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
//Create struct that are nodes that can hold values of function while 1-5 are first five then 6-7 and MUX and Dec//
	//Author:Rishab Das//
    
struct node {
	char * outVar;
	short function;
	char * firstInput;
	char * secondInput;
	char ** inArray;
	char ** selectors;
	int n;
	short evaluated;
	struct node * next;
	short * output;
	short ** multOut;
	char ** decOut; 
};
//creates table//
short ** createTable (int numI, int numO, int rows) {
	short ** table = (short **) malloc (sizeof(short *) * rows);
	if (!table) return NULL;
	int i, j;
	for (i =0; i< (rows); i++) {
		table[i] = (short *) malloc (sizeof(short) * (numI + numO));
		if (!table[i]) return NULL;
	}
	/*init table to all 0s*/
	for (i=0; i<rows; i++) {
		for (j = (numI + numO -1); j>=0; j--) {
			table[i][j]=0;
		}
	}
	table[1][numI-1] = 1;
	for (i=2; i<rows; i++) {
		for (j = (numI + numO -1); j>=0; j--) {
			if (j>=numI) {
				continue;
			}
			if (j==numI-1) {
				table[i][j] = table[i-1][j] + 1;
			} else if (j<numI -1){
				table[i][j] = table[i][j] + table[i-1][j];
			}
			if (table[i][j]==2) {
				table [i][j] = 0;
				table[i][j-1] ++;
			}
		}
	}
	return table;
}
//print table//
void printTable (short ** table, int rows, int columns, int numIn, char ** inputs, char ** outputs) {

	int i, j;

	/*prints the body of the table*/
	for (i=0; i<rows; i++) {
		for (j=0; j<columns; j++) {
			/*adds spacing for the length of the variable name if needed*/
			printf("%d", table[i][j]);
			if (j==numIn-1) {
				printf(" | ");
			}else if (j<columns-1) {
				printf(" ");
			}
		}
		printf("\n");
	}
}
void calcNode67();
void calcMuxNode();
void calcDecNode();
//method to create nodes that hold AND NOR NAND OR XOR five function //
struct node * makeNode15 (char * name, short type, char * A, char * B, int rowNum) {
	struct node * ptr = (struct node * )malloc(sizeof(struct node));
	if (!ptr) return NULL;
	int size =0;
	
	for (size =0; name[size]!='\0'; size++) {
	}size++;
	ptr->outVar = (char *)malloc(sizeof(char)*size);
	if (!ptr->outVar) return NULL;
	strcpy(ptr->outVar, name);
	ptr->function = type;
	
	for (size =0; A[size]!='\0'; size++) {
	}size++;
	ptr->firstInput = (char *)malloc(sizeof(char)*size);
	if (!ptr->firstInput) return NULL;
	strcpy(ptr->firstInput, A);
	
	for (size =0; B[size]!='\0'; size++) {
	}size++;
	ptr->secondInput = (char *)malloc(sizeof(char)*size);
	if (!ptr->secondInput) return NULL;
	strcpy(ptr->secondInput, B);
	
	ptr->inArray = NULL;
 	ptr->decOut = NULL;
 	ptr->selectors = NULL;
 	ptr->multOut=NULL;
	
 	ptr->evaluated = 0;
 	ptr->output = (short *)malloc(sizeof(short) * rowNum);
 	if (!ptr->output) return NULL;
 	for (size=0; size<rowNum; size++) {
 		ptr->output[size] = 2;
 	}
	ptr->next = NULL;
 	ptr->n=0;
	return ptr;
}
struct node * makeNode67 (char * name, short type, char * A, int rowNum) {
	struct node * ptr = (struct node * )malloc(sizeof(struct node));
	if (!ptr) return NULL;
	int size =0;
	for (size =0; name[size]!='\0'; size++) {
	}size++;
	ptr->outVar = (char *)malloc(sizeof(char)*size);
	if (!ptr->outVar) return NULL;
	strcpy(ptr->outVar, name);

	ptr->function = type;
	for (size =0; A[size]!='\0'; size++) {
	}size++;
	ptr->firstInput = (char *)malloc(sizeof(char)*size);
	if (!ptr->firstInput) return NULL;
	strcpy(ptr->firstInput, A);
	ptr->secondInput = NULL;
	ptr->inArray = NULL;
 	ptr->decOut = NULL;
 	ptr->selectors = NULL;
 	ptr->n=0;
 	ptr->multOut=NULL;
 	ptr->evaluated = 0;
 	ptr->output = (short *)malloc(sizeof(short) * rowNum);
 	if (!ptr->output) return NULL;
 	for (size=0; size<rowNum; size++) {
 		ptr->output[size] = 2;
 	}
 	ptr->next = NULL;
	return ptr;
}
struct node * makeMuxNode (char * out, char ** strings, char ** selectors, int rowNum, int n, int length) {
	struct node * ptr = (struct node *)malloc(sizeof(struct node));
	if (!ptr) return NULL;
	int i, j, size;
	for (i=0; out[i]!='\0'; i++) {
	}
	ptr->outVar = (char *)malloc(sizeof(char)* i+1);
	if (!ptr->outVar) return NULL;
	strcpy(ptr->outVar, out);
	ptr->selectors = (char **)malloc(sizeof(char *)* n);
	for (i=0; i<n; i++) {
		for (j=0; selectors[i][j]!='\0'; j++) {
		}
		ptr->selectors[i] = (char *)malloc(sizeof(char)* j +1);
		if (!ptr->selectors[i]) return NULL;
		strcpy(ptr->selectors[i], selectors[i]);
	}
	/*copies the strings into the node*/
	ptr->inArray = (char **)malloc(sizeof(char *)* length);
	for (i=0; i<length; i++) {
		for (j=0; strings[i][j]!='\0'; j++) {
		}
		ptr->inArray[i] = (char *)malloc(sizeof(char)* j +1);
		if (!ptr->inArray[i]) return NULL;
		strcpy(ptr->inArray[i], strings[i]);
	}
	ptr->function = 8;
	ptr->firstInput = NULL;
	ptr->secondInput = NULL;
	ptr->evaluated = 0;
	ptr->next=NULL;
	ptr->n = n;
	ptr->decOut = NULL;
	ptr->multOut=NULL;
	ptr->output = (short *)malloc(sizeof(short) * rowNum);
 	if (!ptr->output) return NULL;
 	for (size=0; size<rowNum; size++) {
 		ptr->output[size] = 3;
 	}
	return ptr;
}
/*method to create a node for a decoder*/
struct node * makeDecNode (char * out, char ** outputs, char ** selectors, int rowNum, int n, int length) {
	struct node * ptr = (struct node *)malloc(sizeof(struct node));
	if (!ptr) return NULL;
	int i, j, size;
	for (i=0; out[i]!='\0'; i++) {
	}
	ptr->outVar = (char *)malloc(sizeof(char)* i+1);
	if (!ptr->outVar) return NULL;
	strcpy(ptr->outVar, out);

	ptr->selectors = (char **)malloc(sizeof(char *)* n);
	for (i=0; i<n; i++) {
		for (j=0; selectors[i][j]!='\0'; j++) {
		}
		ptr->selectors[i] = (char *)malloc(sizeof(char)* j +1);
		if (!ptr->selectors[i]) return NULL;
		strcpy(ptr->selectors[i], selectors[i]);
	}

	ptr->decOut = (char **)malloc(sizeof(char *)* length);
	for (i=0; i<length; i++) {
		for (size=0; outputs[i][size]!='\0'; size++){
		};
		ptr->decOut[i] = (char *)malloc(sizeof(char )* size+1);
		if (!ptr->decOut[i]) return NULL;
		strcpy(ptr->decOut[i], outputs[i]);
	}
	ptr->multOut = (short **) malloc(sizeof(short *) * length);
	if (!ptr->multOut) return NULL;
	for (i=0; i<length; i++) {
		ptr->multOut[i] = (short *) malloc(sizeof(short ) * rowNum);
		if (!ptr->multOut[i])return NULL;
		for (j=0; j<rowNum; j++) {
			ptr->multOut[i][j] = 3;
		}
	}

	ptr->function = 9;
	ptr->firstInput = NULL;
	ptr->secondInput = NULL;
	ptr->evaluated = 0;
	ptr->next=NULL;
	ptr->n = n;
	ptr->inArray = NULL;
	ptr->output = NULL;
	return ptr;
}
void freeAllnode (struct node * ptr) {
	if (ptr==NULL) return;
	if (ptr->next!=NULL) {
		freeAllnode(ptr->next);
	}

	int i, temp=1;
	if (ptr->n!=0) {
		for (i=0; i<ptr->n; i++) {
			temp = temp *2;
		}
	}
	if (ptr->outVar!=NULL) {
		free(ptr->outVar);
	}
	if (ptr->firstInput!=NULL) {
		free(ptr->firstInput);
	}
	if (ptr->secondInput!=NULL) {
		free(ptr->secondInput);
	}
	if (ptr->inArray!=NULL) {
		for (i=0; i<temp; i++) {
			if (ptr->inArray[i]!=NULL){
				free(ptr->inArray[i]);
			}
		}
		free(ptr->inArray);
	}
	/*arrays for decoders and multiplexers*/
	if (ptr->decOut!=NULL){
		for (i=0; i<ptr->n; i++) {
			free(ptr->decOut[i]);
		}
		free(ptr->decOut);
	}
	if (ptr->selectors!=NULL) {
		for (i=0; i<ptr->n; i++) {
			if (ptr->selectors[i]!=NULL){
				free(ptr->selectors[i]);
			}
		}
		free(ptr->selectors);
	}
	if (ptr->output!=NULL) {
		free(ptr->output);
	}
	if (ptr->multOut!=NULL) {
		for (i=0; i<temp; i++) {
			free(ptr->multOut[i]);
		}
		free(ptr->multOut);
	}
}
void freeTable (short ** table, int rows) {

	int i;
	for (i=0; i<rows; i++) {
		free(table[i]);
	}
	free(table);
}
void calcNode15 (struct node * ptr, char ** inputs, char ** outputs, int numberOfInputs, int numberOfOutputs, int rowNum, short ** table, struct node * start) {

	if (ptr==NULL ) return;
	int columnA=-1, columnB=-1, i;
	short * rowA=NULL; short * rowB=NULL;
	if (strcmp(ptr->firstInput, "1")==0) {
		rowA = (short *) malloc(sizeof(short)* rowNum);
		for (i=0; i<rowNum; i++) {
			rowA[i]=1;
		}
		columnA = -2;
	} else if (strcmp(ptr->firstInput, "0")==0) {
		rowA= (short *) malloc(sizeof(short)*rowNum);
		for (i=0; i<rowNum; i++) {
			rowA[i]=0;
		}
		columnA = -2;
	}
	if (strcmp(ptr->secondInput, "0")==0) {
		rowB= (short *) malloc(sizeof(short)*rowNum);
		for (i=0; i<rowNum; i++) {
			rowB[i]=0;
		}
		columnB = -2;
	}else if (strcmp(ptr->secondInput, "1")==0) {
		rowB= (short *) malloc(sizeof(short)*rowNum);
		for (i=0; i<rowNum; i++) {
			rowB[i]=1;
		}
		columnB = -2;
	}

	if (!rowA || !rowB){
		for (i=0; i<numberOfInputs; i++) {
			if (strcmp(ptr->firstInput, inputs[i])==0) {
				columnA = i;
			}
			if (strcmp(ptr->secondInput, inputs[i])==0) {
				columnB = i;
			}
		}
	}
	/*if the inputs for the instruction are not inputs, check to see if they are solves, if not solve them*/
	if (columnA == -1) {
		struct node * current = start;
		while (current != NULL) {
			/*if already solved, pull out its outputs*/
			if (strcmp(current->outVar, ptr->firstInput) == 0) {
				if (current->evaluated==1) {
					rowA = current->output;
					break;
				}else {
					if (current->function <= 5) {
						calcNode15(current, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowA = current->output;
						break;
					}else if (current->function <=7) {
						calcNode67(current, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowA = current->output;
						break;
					} else if (current->function == 8) {
						calcMuxNode(ptr, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowA = current->output;
						break;
					}
				}
			/*check all ouputs of decoder nodes*/
			}else if (strcmp(current->outVar, "DECODER")==0) {
				if (current == ptr) {
					current=current->next;
					continue;
				}
				int temp = 1;
				for (i=0; i<current->n; i++) {
					temp= temp*2;
				}
				for (i=0; i<temp; i++) {
					if (strcmp(ptr->firstInput, current->decOut[i])==0){
						calcDecNode(current, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowA = current->multOut[i];
						break;
					}
				}
			}
			current=current->next;
		}
	} else if (columnA!=-2) {
		rowA = (short *)malloc(sizeof(short)* rowNum);
		for (i=0; i<rowNum; i++) {
			rowA[i]= table[i][columnA];
		}
	}
	/*checks the same for the second arguement*/
	if (columnB == -1) {
		struct node * current = start;
		while (current != NULL) {
			/*if already solved, pull out its outputs*/
			if (strcmp(current->outVar, ptr->secondInput) == 0) {
				if (current->evaluated==1) {
					rowB = current->output;
					for (i=0; i<rowNum; i++) {
					}
					break;
				}else {
					if (current->function <= 5) {
						calcNode15(current, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowB = current->output;
						break;
					}else if (current->function <=7) {
						calcNode67(current, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowB = current->output;
						break;
					} else if (current->function == 8) {
						calcMuxNode(ptr, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowB = current->output;
						break;
					}
				}
			}else if (strcmp(current->outVar, "DECODER")==0) {
				if (current == ptr) {
					current=current->next;
					continue;
				}
				int temp = 1;
				for (i=0; i<current->n; i++) {
					temp= temp*2;
				}
				for (i=0; i<temp; i++) {
					if (strcmp(ptr->secondInput, current->decOut[i])==0){
						calcDecNode(current, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowB = current->multOut[i];
						break;
					}
				}
			}
			current=current->next;
		}
	} else if (columnB!=-2) {
		rowB = (short *)malloc(sizeof(short)* rowNum);
		for (i=0; i<rowNum; i++) {
			rowB[i]= table[i][columnB];
		}
	}
	/*NOW A SECTION TO ACTUALLY DO THE MATH AND CREATE THE OUTPUT ROW*/
	for (i =0; i<rowNum; i++) {
		if (ptr->function==1) {
			int y = rowA[i] + rowB[i];
			if (y==2) {
				ptr->output[i]=1;
			}else {
				ptr->output[i]=0;
			}
		} else if (ptr->function==2) {
			int y = rowA[i] + rowB[i];
			if (y>0) {
				ptr->output[i]=1;
			}else {
				ptr->output[i]=0;
			}
		} else if (ptr->function==3) {
			int y = rowA[i] + rowB[i];
			if (y==1) {
				ptr->output[i]=1;
			}else {
				ptr->output[i]=0;
			}
		} else if (ptr->function==4) {
			int y = rowA[i] + rowB[i];
			if (y==2) {
				ptr->output[i]=0;
			}else {
				ptr->output[i]=1;
			}
		} else {
			int y = rowA[i] + rowB[i];
			if (y>0) {
				ptr->output[i]=0;
			}else {
				ptr->output[i]=1;
			}
		}
	}
	ptr->evaluated = 1;
	int j=0;

	/*updates the table if the node was of an output column in the final table*/
	for (i=0; i<numberOfOutputs; i++) {
		if (strcmp(ptr->outVar, outputs[i])==0) {
			for (j=0; j<rowNum; j++) {
				table[j][numberOfInputs + i] = ptr->output[j];
			}
			break;
		}
	}
}
void calcNode67 (struct node * ptr, char ** inputs, char ** outputs, int numberOfInputs, int numberOfOutputs, int rowNum, short ** table, struct node * start) {
	if (ptr==NULL ) return;
	int columnA=-1;
	short * rowA=NULL;
	int i;
	if (strcmp(ptr->firstInput, "1")==0) {
		rowA= (short *) malloc(sizeof(short)*rowNum);
		for (i=0; i<rowNum; i++) {
			rowA[i]=1;
		}
		columnA = -2;
	} else if (strcmp(ptr->firstInput, "0")==0) {
		rowA= (short *) malloc(sizeof(short)*rowNum);
		for (i=0; i<rowNum; i++) {
			rowA[i]=0;
		}
		columnA = -2;
	}
	if (!rowA) {
	for (i=0; i<numberOfInputs; i++) {
			if (strcmp(ptr->firstInput, inputs[i])==0) {
				columnA = i;
			}
		}
	}
	/*if the inputs for the instruction are not inputs, check to see if they are solves, if not solve them*/
	if (columnA == -1) {
		struct node * current = start;
		while (current != NULL) {
			/*if already solved, pull out its outputs*/
			if (strcmp(current->outVar, ptr->firstInput) == 0) {
				if (current->evaluated==1) {
					rowA = current->output;
					break;
				}else {
					if (current->function <= 5) {
						calcNode15(current, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowA = current->output;
						break;
					}else if (current->function <=7) {
						calcNode67(current, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowA = current->output;
						break;
					} else if (current->function == 8) {
						calcMuxNode(ptr, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowA = current->output;
						break;
					}
				}
			}else if (strcmp(current->outVar, "DECODER")==0) {
				if (current == ptr) {
					current=current->next;
					continue;
				}
				int temp = 1;
				for (i=0; i<current->n; i++) {
					temp= temp*2;
				}
				for (i=0; i<temp; i++) {
					if (strcmp(ptr->firstInput, current->decOut[i])==0){
						calcDecNode(current, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
						rowA = current->multOut[i];
					}
				}
			}

			current=current->next;
		}
	} else if (columnA != -2) {
		rowA = (short *)malloc(sizeof(short)* rowNum);
		for (i=0; i<rowNum; i++) {
			rowA[i]= table[i][columnA];
		}
	}
	/*NOW A SECTION TO ACTUALLY DO THE MATH AND CREATE THE OUTPUT ROW*/
	for (i =0; i<rowNum; i++) {
		if (ptr->function==6) {
			if (rowA[i]==1) {
				ptr->output[i]=0;
			}else {
				ptr->output[i]=1;
			}
		} else  {
			if (rowA[i]==1) {
				ptr->output[i]=1;
			}else {
				ptr->output[i]=0;
			}
		}
	}
	ptr->evaluated = 1;
	int j=0;

	/*updates the table if the node was of an output column in the final table*/
	for (i=0; i<numberOfOutputs; i++) {
		if (strcmp(ptr->outVar, outputs[i])==0) {
			for (j=0; j<rowNum; j++) {
				table[j][numberOfInputs + i] = ptr->output[j];
			}
			break;
		}
	}
}
void calcMuxNode (struct node * ptr, char ** inputs, char ** outputs, int numberOfInputs, int numberOfOutputs, int rows, short ** table, struct node * start) {
	if (ptr==NULL) return;

	int temp = 1, i, j, k, check=0;;
	for (i=0; i<ptr->n; i++) {
		temp = temp *2;
	}

	short ** selectorColumns = (short **)malloc(sizeof(short *) * ptr->n);
	if (!selectorColumns) return;
	short** stringColumns = (short **)malloc(sizeof(short *) * temp);
	if (!stringColumns) return;
	for (i=0; i<temp; i++) {
		if (i<ptr->n) {
			selectorColumns[i] = (short * )malloc(sizeof(short) * rows);
			if (!selectorColumns[i]) return;
		}
		stringColumns[i] = (short *) malloc(sizeof(short) * rows);
		if (!stringColumns[i]) return;
	}
	for (i=0; i<temp; i++) {
		for (j=0; j<rows; j++) {
			if (i<ptr->n) {
				selectorColumns[i][j]=2;
			}
			stringColumns[i][j]=2;
		}
	}
	/*checks to make sure each of the string output determiners are solved*/
		/*also copies the values for each item at each row into arrays (one for selectors, one for input string)*/
	for (i=0; i<temp; i++ ) {
		check=0;
		if (strcmp(ptr->inArray[i], "1")==0) {
			for (j=0; j<rows; j++) {
				stringColumns[i][j]= 1;
			}
			continue;
		} else if (strcmp(ptr->inArray[i], "0")==0) {
			for (j=0; j<rows; j++) {
				stringColumns[i][j]= 0;
			}
			continue;
		}
		for (j=0; j<numberOfInputs; j++) {
			if (strcmp(inputs[j], ptr->inArray[i])==0) {
				check = 1;
				for (k=0; k<rows; k++) {
					stringColumns[i][k]= table[k][j];
				}
			}
		}
		if (check==1) continue;
		/*if not a 1, 0, o input, check to make sure it is solved. if not, solve it*/
		struct node * current = start;
		while (current != NULL) {
			/*if already solved, pull out its outputs*/
			if (strcmp(current->outVar, ptr->inArray[i]) == 0) {
				if (current->evaluated==1) {
					for (j=0; j<rows; j++) {
						stringColumns[i][j]= current->output[j];
					}
					break;
				}else {
					if (current->function <= 5) {
						calcNode15(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						for (j=0; j<rows; j++) {
							stringColumns[i][j]= current->output[j];
						}
						break;
					}else if (current->function <=7) {
						calcNode67(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						for (j=0; j<rows; j++) {
							stringColumns[i][j]= current->output[j];
						}
						break;
					} else if (current->function == 8) {
						calcMuxNode(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						for (j=0; j<rows; j++) {
							stringColumns[i][j]= current->output[j];
						}
						break;
					}
				}
			}else if (strcmp(current->outVar, "DECODER")==0) {
				if (current == ptr) {
					current=current->next;
					continue;
				}
				int square = 1;
				for (j=0; j<current->n; j++) {
					square = square*2;
				}
				for (j=0; j<square; j++) {
					if (strcmp(ptr->inArray[i], current->decOut[j])==0){
						calcDecNode(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						stringColumns[i] = current->multOut[j];
					}
				}
			}
			current=current->next;
		}
	}
	/*does the same thing again for the selectors*/
	for (i=0; i<ptr->n; i++ ) {
		check=0;
		if (strcmp(ptr->selectors[i], "1")==0) {
			for (j=0; j<rows; j++) {
				selectorColumns[i][j]= 1;
			}
			continue;
		} else if (strcmp(ptr->selectors[i], "0")==0) {
			for (j=0; j<rows; j++) {
				selectorColumns[i][j]= 0;
			}
			continue;
		}
		for (j=0; j<numberOfInputs; j++) {
			if (strcmp(inputs[j], ptr->selectors[i])==0) {
				for (k=0; k<rows; k++) {
					selectorColumns[i][k]= table[k][j];
				}
			continue;
			}
		}
		/*if not a 1, 0, o input, check to make sure it is solved. if not, solve it*/
		struct node * current = start;
		while (current != NULL) {
			/*if already solved, pull out its outputs*/
			if (strcmp(current->outVar, ptr->selectors[i]) == 0) {
				if (current->evaluated==1) {
					for (j=0; j<rows; j++) {
						selectorColumns[i][j]= current->output[j];
					}
					break;
				}else {
					if (current->function <= 5) {
						calcNode15(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						for (j=0; j<rows; j++) {
							selectorColumns[i][j]= current->output[j];
						}
						break;
					}else if (current->function <=7) {
						calcNode67(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						for (j=0; j<rows; j++) {
							selectorColumns[i][j]= current->output[j];
						}
						break;
					} else if (current->function == 8) {
						calcMuxNode(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						for (j=0; j<rows; j++) {
							selectorColumns[i][j]= current->output[j];
						}
						break;
					}
				}
			}else if (strcmp(current->outVar, "DECODER")==0) {
				if (current == ptr) {
					current=current->next;
					continue;
				}
				int square= 1;
				for (j=0; j<current->n; j++) {
					square = square*2;
				}
				for (j=0; j<square; j++) {
					if (strcmp(ptr->selectors[i], current->decOut[j])==0){
						calcDecNode(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						selectorColumns[i] = current->multOut[j];
					}
				}
			}
			current=current->next;
		}
	}
	
	int entry=0;
	for (i=0; i<rows; i++) {
		entry = 0;
		/*picks entry from selector*/
		for (j=0; j<ptr->n; j++) {
			entry = entry*2;
			if (selectorColumns[j][i] == 1) {
                //If value has 1 and not 2 then it adds//
				entry += 1;
			}
		}
		/*evaluates entry*/
		ptr->output[i] = stringColumns[entry][i];
	}
	ptr->evaluated = 1;

	for (i=0; i<numberOfOutputs; i++) {
		if (strcmp(ptr->outVar, outputs[i])==0) {
			for (j=0; j<rows; j++) {
				table[j][numberOfInputs + i] = ptr->output[j];
			}
			break;
		}
	}
}
void calcDecNode (struct node * ptr, char ** inputs, char ** outputs, int numberOfInputs, int numberOfOutputs, int rows, short ** table, struct node * start) {
	if (ptr==NULL) return;

	int temp = 1, i, j, k, stop=1;;
	for (i=0; i<ptr->n; i++) {
		temp = temp *2;
		stop=stop*2;
	}
	short ** selectorColumns = (short **)malloc(sizeof(short *) * ptr->n);
	if (!selectorColumns) return;
	for (i=0; i<ptr->n; i++) {
		selectorColumns[i] = (short * )malloc(sizeof(short) * rows);
		if (!selectorColumns[i]) return;
	}
	for (i=0; i<ptr->n; i++) {
		for (j=0; j<rows; j++) {
			selectorColumns[i][j]=17;
		}
	}
	/*checks to make sure if the inputs for the decoder are already solved*/
	for (i=0; i<ptr->n; i++ ) {
		if (strcmp(ptr->selectors[i], "1")==0) {
			for (j=0; j<rows; j++) {
				selectorColumns[i][j]= 1;
			}
			continue;
		} else if (strcmp(ptr->selectors[i], "0")==0) {
			for (j=0; j<rows; j++) {
				selectorColumns[i][j]= 0;
			}
			continue;
		}
		for (j=0; j<numberOfInputs; j++) {
			if (strcmp(inputs[j], ptr->selectors[i])==0) {
				for (k=0; k<rows; k++) {
					selectorColumns[i][k]= table[k][j];
				}
			continue;
			}
		}
		/*if not a 1, 0, o input, check to make sure it is solved. if not, solve it*/
		struct node * current = start;
		while (current != NULL) {
			/*if already solved, pull out its outputs*/
			if (strcmp(current->outVar, ptr->selectors[i]) == 0) {
				if (current->evaluated==1) {
					for (j=0; j<rows; j++) {
						selectorColumns[i][j]= current->output[j];
					}
					break;
				}else {
					if (current->function <= 5) {
						calcNode15(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						for (j=0; j<rows; j++) {
							selectorColumns[i][j]= current->output[j];
						}
						break;
					}else if (current->function <=7) {
						calcNode67(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						for (j=0; j<rows; j++) {
							selectorColumns[i][j]= current->output[j];
						}
						break;
					} else if (current->function == 8) {
						calcMuxNode(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						for (j=0; j<rows; j++) {
							selectorColumns[i][j]= current->output[j];
						}
						break;
					}
				}
			}else if (strcmp(current->outVar, "DECODER")==0) {
				if (current == ptr) {
					current=current->next;
					continue;
				}
				int square = 1;
				for (j=0; j<current->n; j++) {
					square= square*2;
				}
				for (j=0; j<square; j++) {
					if (strcmp(ptr->selectors[i], current->decOut[j])==0){
						calcDecNode(current, inputs, outputs, numberOfInputs, numberOfOutputs, rows, table, start);
						selectorColumns[i] = current->multOut[j];
					}
				}
			}
			current=current->next;
		}
	}
	/*the math for the decoder*/
	int entry=0;
	for (i=0; i<rows; i++) {
		entry = 0;
		/*picks entry from selector*/
		for (j=0; j<ptr->n; j++) {
			entry = entry*2;
			if (selectorColumns[j][i] == 1) {
				entry += 1;
			}
		}
		/*evaluates entry*/
		/*ptr->output[i] = ptr->decOut[entry];*/
		for (k=0; k<stop; k++) {
			ptr->multOut[k][i] = 0;
			if (k==entry) {
				ptr->multOut[k][i]=1;
			}
		}
	}
	ptr->evaluated = 1;
	/*copies the outputs into the table if they are final outputs*/
	for (i=0; i<numberOfOutputs; i++) {
		for (k=0; k<temp; k++) {
			if (strcmp(ptr->decOut[k], outputs[i])==0) {
				for (j=0; j<rows; j++) {
					table[j][numberOfInputs + i] = ptr->multOut[k][j];
				}
				break;
			}
		}
	}
}
void calcAll (struct node * start, char ** inputs, char ** outputs, int numberOfInputs, int numberOfOutputs, int rowNum, short ** table) {

	struct node * ptr = start;
	if (ptr==NULL) return;
	while (ptr!=NULL) {
		if (ptr->evaluated == 1) {
			ptr = ptr->next;
			continue;
		} else if (ptr->function <=5 ) {
			calcNode15(ptr, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
		} else if (ptr->function <=7) {
			calcNode67(ptr, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
		}else if (ptr->function==8) {
			calcMuxNode(ptr, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
		} else {
			calcDecNode(ptr, inputs, outputs, numberOfInputs, numberOfOutputs, rowNum, table, start);
		}
		ptr = ptr->next;
	}
}
int main (int argc, char ** argv) {
	short ** table =NULL;
	int numIn = 0, numOut = 0, rows = 1;
	int i, j, rCount;
	char ** inputs = NULL;
	char ** outputs = NULL;
	struct node * start = NULL;
	struct node * current = start;
	char * read = (char *) malloc (sizeof(char) * 300);
	/*Read from file */
    if (argc - 1 != 1) {
        printf("Invalid number of arguments\n");
        return 0;
    }
	FILE *file = fopen(argv[1], "r");
	if (!file) return 1;
	// Read input line//
	fscanf(file, "%s %d", read, &numIn);
	//puts input in array//
	inputs = (char ** )malloc(sizeof(char *) * numIn);
	for (i=0; i<numIn; i++) {
		fscanf(file, "%s ", read) ;
		for (j=0; read[j]!='\0'; j++) {
			continue;
		}
		inputs[i] = (char *)malloc(sizeof(char *) * j+1 );
		strcpy(inputs[i], read);
	}
    //read Output names//
    fscanf(file, "%s %d", read, &numOut);

    outputs = (char **)malloc(sizeof(char *) * numOut);
    for (i=0; i<numOut; i++) {
        fscanf(file, "%s ", read);
       for (j=0; read[j]!='\0'; j++) {
            continue;
        }
        outputs[i] = (char *)malloc(sizeof(char *) * j+1 );
        strcpy(outputs[i], read);
   }
    for (rCount=0; rCount<numIn; rCount++) {
        rows = rows*2;
    }
    //creates table with input output and rows//
    table = createTable(numIn, numOut, rows);
   //reads line by line creating a node for each line //
    while (fscanf(file, "%s ", read)==1) {
       //Reads if it is 1-5 and puts in node//
        if (strcmp(read, "AND")==0 || strcmp(read, "OR")==0 || 
			strcmp(read, "XOR")==0 || strcmp(read, "NOR")==0 || 
			strcmp (read, "NAND") ==0){
           int functionType; char * B = (char *)malloc(sizeof(char) * 300);
            char * out = (char *) malloc (sizeof(char) * 300);
           if (strcmp(read, "AND")==0) {
                functionType=1;
            } else if (strcmp(read, "OR")==0) {
                functionType = 2;
            } else if (strcmp(read, "XOR")==0) {
                functionType=3;
            }else if (strcmp(read, "NAND")==0) {
                functionType=4;
            }else {
                functionType=5;
            }
           fscanf(file, "%s %s %s", read, B, out);
            if (strcmp(out, ":")==0){
                fscanf(file, "%s ", out);
            }
           struct node * ptr = makeNode15(out, functionType, read, B, rows);
            
            if (start==NULL) {
                start = ptr;
                current = start;
            } else {
                current->next =ptr;
                current = current->next;
            }
           free(out);
           free(B);
       
        //if function 6-7//
        } else if (strcmp (read, "NOT")==0 || strcmp(read, "PASS")==0) {
           int functionType; char * out = (char *)malloc(sizeof(char) * 300);
           if (strcmp(read, "NOT")==0) {
                functionType= 6;
            } else {
                functionType = 7;
            }
           fscanf(file, "%s %s", read, out);
            if (strcmp(out, " ")==0) {
                fscanf(file, "%s ", out);
            }
           struct node * ptr = makeNode67(out, functionType, read, rows);
            if (!ptr) return 1;
            if (start==NULL) {
                start = ptr;
                current = start;
            } else {
                current->next = ptr;
                current = current->next;
            }
           free(out);
       
        //if function 8//
        } else if (strcmp(read, "MULTIPLEXER")==0) {
           char * out = (char *)malloc(sizeof(char) * 300);
            int n, length=1, j;
            fscanf(file, " %d ", &n);
            for (j=0; j<n; j++) {
                length = length*2;
            };
           /*create something to hold the string of outputs*/
            char ** strings = (char ** ) malloc(sizeof(char *) * length);
            if (!strings)return 1;
            for (j=0; j<length; j++) {
                strings[j] = (char *)malloc(sizeof(char) * 100);
                if (!strings[j])return 1;
            }
            /*create something to hold the selectors*/
            char ** selectors = (char ** ) malloc(sizeof(char * )*n);
            if (!selectors)return 1;
            for (j=0; j<n; j++) {
                selectors[j] = (char *)malloc(sizeof(char) * 100);
                if (!selectors[j])return 1;
            }
           /*copy the output options into strings*/
            if (fscanf(file, "%s ", read) != 1) return 1;
            if (strcmp(read, " ")==0) {
                if (fscanf(file, "%s ", read) != 1) return 1;
            }
            strcpy(strings[0], read);
            for (j=1; j<length; j++) {
            if (fscanf(file, "%s ", read) != 1) return 1;
                strcpy(strings[j], read);
            }
           
           /*copy the selctors into selectors*/
            if (fscanf(file, "%s ", read) != 1) return 1;
            if (strcmp(read, ":")==0) {
                if (fscanf(file, "%s ", read) != 1) return 1;
            }
            strcpy(selectors[0], read);
            for (j=1; j<n; j++) {
                if (fscanf(file, "%s ", read) != 1) return 1;
                strcpy(selectors[j], read);
            }
       /*copy the output name into out and frees malloc*/
            if (fscanf(file, "%s ", read) != 1) return 1;
            if (strcmp(read, ":")==0) {
                if (fscanf(file, "%s ", read) != 1) return 1;
            }
            strcpy(out, read);
           struct node * ptr = makeMuxNode(out, strings, selectors, rows, n, length);
            if (!ptr) return 1;
           for (j=0; j<length; j++) {
                if (j<n) {
                    free(selectors[j]);
                }
                free(strings[j]);
            }
            free(selectors);
            free(out);
            free(strings);
           if (start==NULL) {
                start = ptr;
                current = start;
            } else {
                current->next =ptr;
                current = current->next;
            }
       //if functionType 9 //
        } else {
           int n, length=1, j;
           fscanf(file, "%d ", &n);
           for (j=0; j<n; j++) {
                length = length*2;
            };
            char ** selectors = (char ** ) malloc(sizeof(char * ) * n);
            if (!selectors)return 1;
            for (j=0; j<n; j++) {
                selectors[j] = (char *)malloc(sizeof(char) * 100);
                if (!selectors[j])return 1;
            }
            char ** output = (char ** ) malloc(sizeof(char *) * length);
            if (!output)return 1;
            for (j=0; j<length; j++) {
                output[j] = (char * ) malloc(sizeof(char *) * 100);
                if (!output[j] )return 1;
            }
            
           /*copy the selctors into selectors*/
            if (fscanf(file, "%s ", read) != 1) return 1;
            if (strcmp(read, " ")==0) {
                if (fscanf(file, "%s ", read) != 1) return 1;
            }
            strcpy(selectors[0], read);
            for (j=1; j<n; j++) {
                if (fscanf(file, "%s ", read) != 1) return 1;
                strcpy(selectors[j], read);
            }
           /*copy the output options into output*/
            if (fscanf(file, "%s ", read) != 1) return 1;
            if (strcmp(read, " ")==0) {
                if (fscanf(file, "%s ", read) != 1) return 1;
            }
            strcpy(output[0], read);
            for (j=1; j<length; j++) {
                if (fscanf(file, "%s ", read) != 1) return 1;
                strcpy(output[j], read);
            }
           struct node * ptr = makeDecNode("DECODER", output, selectors, rows, n, length);
            if (!ptr) return 1;
           for (j=0; j<n; j++) {
                free(selectors[j]);
            }
            free(selectors);
            free(output);
           if (start==NULL) {
                start = ptr;
                current = start;
            } else {
                current->next =ptr;
                current = current->next;
            }
        }
    }
	if (current!=NULL){
		current->next = NULL;
	}
	calcAll(start, inputs, outputs, numIn, numOut, rows, table);
	printTable(table, rows, (numIn+numOut), numIn, inputs, outputs);
	freeAllnode(start);
	freeTable(table, rows);
	
}